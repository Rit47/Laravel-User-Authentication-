laravel-authentication-acl
==========================

Hello Sir / Madam 

I am Ritesh Deshapande an recent engineering graduate.

In reference to your Task to ,

"Create a basic authentication system using Laravel framework that includes generating a unique identifier (ID) for each registered user.Create a basic authentication system using Laravel framework that includes generating a unique identifier (ID) for each registered user."

I Have created Create a basic authentication system Project.

I hope I have cleared the basic requirements. And hope to meet your expectations.

Thank You.

Yours Sincerely,

Ritesh Deshapande
7795850451
rrider4774@gmail.com