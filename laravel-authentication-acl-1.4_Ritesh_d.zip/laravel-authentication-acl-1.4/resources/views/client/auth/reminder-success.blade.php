@extends('laravel-authentication-acl::client.layouts.base-fullscreen')
@section ('title')
Password recovery
@stop
@section('content')
<div class="row">
    <div class="col-lg-12 text-center v-center">

        <h1><i class="fa fa-download"></i> Request received</h1>
        <p class="lead">We sent you the information to recover your password. Please check your inbox.</p>
    </div>
</div>
@stop