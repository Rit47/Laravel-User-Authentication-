<?php  namespace LaravelAcl\Authentication\Models;
/**
 * Class BaseModel
 *
 * @author jacopo beschi jacopo@jacopobeschi.com
 */
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model
{
}