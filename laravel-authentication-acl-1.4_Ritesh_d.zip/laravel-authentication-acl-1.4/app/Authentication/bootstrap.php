<?php
// increase max nesting level
ini_set('xdebug.max_nesting_level', 250);