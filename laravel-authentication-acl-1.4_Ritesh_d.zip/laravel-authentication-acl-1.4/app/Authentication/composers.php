<?php
require __DIR__ . '/Composers/menu.php';

require __DIR__ . '/Composers/select_items.php';

require __DIR__ . '/Composers/dashboard.php';

require __DIR__ . '/Composers/permissions.php';

require __DIR__ . '/Composers/others.php';
