<?php namespace LaravelAcl\Library\Exceptions;

class ValidationException extends \Exception implements JacopoExceptionsInterface {}