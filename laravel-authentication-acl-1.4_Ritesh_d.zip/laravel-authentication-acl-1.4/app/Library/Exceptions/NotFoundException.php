<?php namespace LaravelAcl\Library\Exceptions;

class NotFoundException extends \Exception implements JacopoExceptionsInterface {}