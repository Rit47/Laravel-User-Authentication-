<?php namespace LaravelAcl\Library\Exceptions;
/**
 * Interface JacopoExceptionsInterface
 *
 * To catch multiple exceptions
 *
 * @package Exceptions
 */
interface JacopoExceptionsInterface {}