<?php namespace LaravelAcl\Library\Exceptions;

class MailException extends \Exception implements JacopoExceptionsInterface {}