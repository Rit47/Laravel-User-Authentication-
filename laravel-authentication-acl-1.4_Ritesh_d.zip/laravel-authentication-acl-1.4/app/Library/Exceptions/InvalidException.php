<?php namespace LaravelAcl\Library\Exceptions;

class InvalidException extends \Exception implements JacopoExceptionsInterface {}